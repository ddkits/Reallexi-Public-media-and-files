import { a as groupLogs, c as buildPreferredSolutionSearchUrl, f as DEFAULT_SETTINGS, m as normalizeSettings, n as createConsoleEntry, o as pruneLogs, p as STORAGE_KEYS, t as applyEntryUpdate } from "./logStore.js";
//#region src/background/serviceWorker.ts
var RETENTION_ALARM = "betterConsole.retentionSweep";
chrome.runtime.onInstalled.addListener(() => {
	initializeExtension();
});
chrome.runtime.onStartup.addListener(() => {
	initializeExtension({ resetForStartup: true });
});
chrome.tabs.onActivated.addListener(({ tabId }) => {
	refreshCaptureForTab(tabId, { silent: true });
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
	if (changeInfo.status === "complete") refreshCaptureForTab(tabId, { silent: true });
});
chrome.alarms.onAlarm.addListener((alarm) => {
	if (alarm.name === RETENTION_ALARM) runRetentionSweep();
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	handleMessage(message, sender).then((response) => sendResponse(response)).catch((error) => sendResponse({
		ok: false,
		error: error.message
	}));
	return true;
});
async function initializeExtension({ resetForStartup = false } = {}) {
	const current = await chrome.storage.local.get([
		STORAGE_KEYS.logs,
		STORAGE_KEYS.settings,
		"logs"
	]);
	const settings = normalizeSettings(current[STORAGE_KEYS.settings]);
	const migratedLogs = resetForStartup && settings.startupLogMode === "reset" ? [] : current[STORAGE_KEYS.logs] || current.logs || [];
	await chrome.storage.local.set({
		[STORAGE_KEYS.logs]: migratedLogs,
		[STORAGE_KEYS.settings]: settings
	});
	await chrome.storage.local.remove("logs");
	await chrome.alarms.create(RETENTION_ALARM, { periodInMinutes: 60 });
	if (chrome.sidePanel?.setPanelBehavior) await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => void 0);
	const [tab] = await chrome.tabs.query({
		active: true,
		currentWindow: true
	}).catch(() => []);
	if (tab?.id) refreshCaptureForTab(tab.id, { silent: true });
}
async function handleMessage(message, sender) {
	switch (message.type) {
		case "logEntry": return addLogEntry(message.payload, sender);
		case "getState": return getState();
		case "clearLogs": return clearLogs(message.tabId);
		case "updateIssue": return updateIssue(message.fingerprint, message.update);
		case "saveSettings": return saveSettings(message.settings);
		case "openSidePanel": return openSidePanel();
		case "openOptions":
			await chrome.runtime.openOptionsPage();
			return { ok: true };
		case "openSolutionSearch": return openSolutionSearch(message.query);
		case "enableCaptureForActiveTab": return enableCaptureForActiveTab();
		case "downloadText": return downloadText(message.filename, message.mime, message.content);
		default: return {
			ok: false,
			error: "Unknown message type"
		};
	}
}
async function getState() {
	const [logs, settings] = await Promise.all([readLogs(), readSettings()]);
	return {
		logs,
		groups: groupLogs(logs),
		settings
	};
}
async function addLogEntry(payload, sender) {
	const settings = await readSettings();
	if (!settings.captureEnabled) return { ok: true };
	const logs = await readLogs();
	const entry = createConsoleEntry({
		...payload,
		tabId: sender.tab?.id ?? payload.tabId,
		tabTitle: sender.tab?.title ?? payload.tabTitle,
		pageUrl: sender.tab?.url ?? payload.pageUrl,
		frameUrl: sender.url ?? payload.frameUrl
	}, settings);
	const ignored = settings.ignoredPatterns.some((pattern) => entry.cleanMessage.toLowerCase().includes(pattern.toLowerCase()));
	const nextLogs = pruneLogs([...logs, ignored ? {
		...entry,
		status: "ignored"
	} : entry], settings);
	await chrome.storage.local.set({ [STORAGE_KEYS.logs]: nextLogs });
	return { ok: true };
}
async function clearLogs(tabId) {
	const logs = await readLogs();
	const nextLogs = tabId ? logs.filter((entry) => entry.tabId !== tabId) : [];
	await chrome.storage.local.set({ [STORAGE_KEYS.logs]: nextLogs });
	return { ok: true };
}
async function updateIssue(fingerprint, update) {
	const logs = await readLogs();
	await chrome.storage.local.set({ [STORAGE_KEYS.logs]: applyEntryUpdate(logs, fingerprint, update) });
	return { ok: true };
}
async function saveSettings(settingsUpdate) {
	const settings = normalizeSettings({
		...await readSettings(),
		...settingsUpdate
	});
	const logs = pruneLogs(await readLogs(), settings);
	await chrome.storage.local.set({
		[STORAGE_KEYS.settings]: settings,
		[STORAGE_KEYS.logs]: logs
	});
	const nextState = await getState();
	if (settings.captureEnabled) refreshActiveTabCapture();
	return nextState;
}
async function openSidePanel() {
	const [tab] = await chrome.tabs.query({
		active: true,
		currentWindow: true
	});
	if (!tab?.id || !chrome.sidePanel?.open) return {
		ok: false,
		error: "No active tab is available."
	};
	await chrome.sidePanel.open({ tabId: tab.id });
	return { ok: true };
}
async function openSolutionSearch(query) {
	const url = buildPreferredSolutionSearchUrl(query, navigator.userAgent);
	await chrome.tabs.create({ url });
	return {
		ok: true,
		url
	};
}
async function enableCaptureForActiveTab() {
	const [tab] = await chrome.tabs.query({
		active: true,
		currentWindow: true
	});
	if (!tab?.id) return {
		ok: false,
		error: "No active tab is available."
	};
	return refreshCaptureForTab(tab.id, { silent: false });
}
async function refreshActiveTabCapture() {
	const [tab] = await chrome.tabs.query({
		active: true,
		currentWindow: true
	}).catch(() => []);
	if (tab?.id) await refreshCaptureForTab(tab.id, { silent: true });
}
async function refreshCaptureForTab(tabId, { silent }) {
	if (!(await readSettings()).captureEnabled) return {
		ok: false,
		error: "Capture is paused. Resume capture before refreshing this tab."
	};
	try {
		await chrome.scripting.executeScript({
			target: {
				tabId,
				allFrames: true
			},
			files: ["assets/consoleCapture.js"]
		});
		return { ok: true };
	} catch (error) {
		if (silent) return { ok: false };
		return {
			ok: false,
			error: error instanceof Error ? error.message : "Capture refresh failed."
		};
	}
}
async function downloadText(filename, mime, content) {
	const url = `data:${mime};charset=utf-8,${encodeURIComponent(content)}`;
	return {
		ok: true,
		downloadId: await chrome.downloads.download({
			url,
			filename,
			saveAs: true
		})
	};
}
async function runRetentionSweep() {
	const settings = await readSettings();
	const logs = pruneLogs(await readLogs(), settings);
	await chrome.storage.local.set({ [STORAGE_KEYS.logs]: logs });
}
async function readLogs() {
	return (await chrome.storage.local.get([STORAGE_KEYS.logs]))[STORAGE_KEYS.logs] || [];
}
async function readSettings() {
	return normalizeSettings((await chrome.storage.local.get([STORAGE_KEYS.settings]))[STORAGE_KEYS.settings] || DEFAULT_SETTINGS);
}
//#endregion
