//#region src/core/settings.ts
var STORAGE_KEYS = {
	logs: "betterConsole.logs",
	settings: "betterConsole.settings"
};
var DEFAULT_SETTINGS = {
	theme: "system",
	retentionDays: 14,
	maxLogs: 5e3,
	captureEnabled: true,
	startupLogMode: "keep",
	cleanupDuplicates: true,
	hideExtensionNoise: true,
	maskEmails: true,
	maskSecrets: true,
	maskQueryParams: true,
	maskPrivateUrls: true,
	maskIpAddresses: false,
	maskLocalhostPorts: false,
	defaultSearchTarget: "Google",
	enabledSearchTargets: [
		"Google",
		"Bing",
		"Stack Overflow",
		"GitHub Issues",
		"MDN"
	],
	ignoredPatterns: [
		"ResizeObserver loop limit exceeded",
		"A listener indicated an asynchronous response",
		"DevTools failed to load source map"
	],
	developerMode: false
};
function normalizeSettings(value) {
	return {
		...DEFAULT_SETTINGS,
		...value || {},
		enabledSearchTargets: value?.enabledSearchTargets && value.enabledSearchTargets.length > 0 ? value.enabledSearchTargets : DEFAULT_SETTINGS.enabledSearchTargets,
		ignoredPatterns: value?.ignoredPatterns || DEFAULT_SETTINGS.ignoredPatterns
	};
}
//#endregion
//#region src/core/analysis.ts
var SEARCH_ENDPOINTS = {
	Google: (query) => `https://www.google.com/search?q=${encodeURIComponent(query)}`,
	Bing: (query) => `https://www.bing.com/search?q=${encodeURIComponent(query)}`,
	"Stack Overflow": (query) => `https://stackoverflow.com/search?q=${encodeURIComponent(query)}`,
	"GitHub Issues": (query) => `https://github.com/search?type=issues&q=${encodeURIComponent(query)}`,
	MDN: (query) => `https://developer.mozilla.org/en-US/search?q=${encodeURIComponent(query)}`,
	Docs: (query) => `https://www.google.com/search?q=${encodeURIComponent(`${query} official docs`)}`
};
function buildSearchUrl(target, query) {
	const cleanQuery = query.trim() || "browser console error";
	return SEARCH_ENDPOINTS[target](cleanQuery);
}
function getPreferredSearchTarget(userAgent = "") {
	return /\bEdg\//.test(userAgent) ? "Bing" : "Google";
}
function buildPreferredSolutionSearchUrl(query, userAgent = "") {
	return buildSearchUrl(getPreferredSearchTarget(userAgent), query);
}
function sanitizeText(input, settings = DEFAULT_SETTINGS) {
	let cleanText = input || "";
	let maskedCount = 0;
	const appliedRules = [];
	const apply = (enabled, rule, pattern, replacement) => {
		if (!enabled) return;
		const matches = cleanText.match(pattern);
		if (!matches) return;
		maskedCount += matches.length;
		appliedRules.push(rule);
		cleanText = cleanText.replace(pattern, replacement);
	};
	apply(settings.maskSecrets, "authorization headers", /\bBearer\s+[A-Za-z0-9._~+/=-]+/gi, "Bearer [masked-token]");
	apply(settings.maskSecrets, "jwt tokens", /\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g, "[masked-jwt]");
	apply(settings.maskSecrets, "api keys", /\b(api[_-]?key|token|secret|client_secret|access_token)=([^&\s]+)/gi, "$1=[masked]");
	apply(settings.maskSecrets, "cookies", /\b(cookie|set-cookie):\s*[^;\n]+/gi, "$1: [masked-cookie]");
	apply(settings.maskEmails, "emails", /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[masked-email]");
	apply(settings.maskQueryParams, "query parameters", /(https?:\/\/[^\s?#]+)\?[^#\s]*/gi, "$1?[masked-query]");
	apply(settings.maskPrivateUrls, "private urls", /\bhttps?:\/\/(localhost|127\.0\.0\.1|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[0-1])\.\d+\.\d+)(?::\d+)?\/[^\s)]*/gi, "http://[masked-private-url]");
	apply(settings.maskIpAddresses, "ip addresses", /\b(?:\d{1,3}\.){3}\d{1,3}\b/g, "[masked-ip]");
	apply(settings.maskLocalhostPorts, "localhost ports", /\b(localhost|127\.0\.0\.1):\d+\b/gi, "$1:[masked-port]");
	return {
		cleanText,
		maskedCount,
		appliedRules: Array.from(new Set(appliedRules))
	};
}
function parseStack(stackTrace) {
	if (!stackTrace) return [];
	return stackTrace.split("\n").map((line) => line.trim()).map((line) => {
		const chromeMatch = line.match(/^at\s+(?:(.*?)\s+\()?(.+):(\d+):(\d+)\)?$/);
		if (chromeMatch) return {
			functionName: chromeMatch[1] || void 0,
			fileName: chromeMatch[2],
			lineNumber: Number(chromeMatch[3]),
			columnNumber: Number(chromeMatch[4])
		};
		const firefoxMatch = line.match(/^(.*?)@(.+):(\d+):(\d+)$/);
		if (firefoxMatch) return {
			functionName: firefoxMatch[1] || void 0,
			fileName: firefoxMatch[2],
			lineNumber: Number(firefoxMatch[3]),
			columnNumber: Number(firefoxMatch[4])
		};
		return null;
	}).filter((frame) => Boolean(frame));
}
function detectFrameworkHints(text, pageUrl = "") {
	const haystack = `${text} ${pageUrl}`.toLowerCase();
	return [
		[
			"React",
			/\breact\b|react-dom|jsx|hydration|hooks? can only be called/i,
			"React error patterns"
		],
		[
			"Next.js",
			/\bnext\b|_next\/|next-router|hydration failed/i,
			"Next.js runtime markers"
		],
		[
			"Vue",
			/\bvue\b|vue-router|nuxt|computed property/i,
			"Vue runtime markers"
		],
		[
			"Nuxt",
			/\bnuxt\b|__nuxt/i,
			"Nuxt runtime markers"
		],
		[
			"Angular",
			/\bangular\b|zone\.js|ngmodule|ngrx/i,
			"Angular runtime markers"
		],
		[
			"Svelte",
			/\bsvelte\b|sveltekit/i,
			"Svelte runtime markers"
		],
		[
			"Astro",
			/\bastro\b|astro-island/i,
			"Astro runtime markers"
		],
		[
			"Vite",
			/\bvite\b|@vite|vite\/client/i,
			"Vite dev server markers"
		],
		[
			"Webpack",
			/\bwebpack\b|webpack-internal/i,
			"Webpack bundle markers"
		],
		[
			"TypeScript",
			/\btypescript\b|\.tsx?|tslib/i,
			"TypeScript source markers"
		],
		[
			"Tailwind CSS",
			/\btailwind\b|tw-/i,
			"Tailwind class markers"
		],
		[
			"Three.js",
			/\bthree\b|webgl|react-three-fiber|r3f/i,
			"Three.js or WebGL markers"
		]
	].filter(([, pattern]) => pattern.test(haystack)).map(([name, , evidence]) => ({
		name,
		confidence: name === "React" ? .82 : .72,
		evidence
	}));
}
function getSeverity(level, kind, message) {
	const text = message.toLowerCase();
	if (kind === "csp" || text.includes("content security policy")) return "high";
	if (kind === "promise" || text.includes("uncaught") || text.includes("unhandled")) return "high";
	if (level === "error") return text.includes("security") || text.includes("cors") ? "critical" : "high";
	if (level === "warn" || kind === "resource" || kind === "network") return "medium";
	return "low";
}
function buildFixSuggestions(entry) {
	const message = entry.message.toLowerCase();
	const suggestions = [];
	if (message.includes("cannot read") || message.includes("undefined") || message.includes("null")) suggestions.push({
		title: "Guard the value before reading from it",
		explanation: "The code is probably accessing a property before the value exists.",
		steps: [
			"Confirm the variable is initialized before render or event handling.",
			"Use optional chaining for genuinely optional data.",
			"Add a loading or empty state before using API response fields."
		],
		confidence: .86
	});
	if (message.includes("cors")) suggestions.push({
		title: "Check the API CORS response headers",
		explanation: "The browser blocked the request before application code could read the response.",
		steps: [
			"Verify Access-Control-Allow-Origin matches the requesting origin.",
			"Confirm allowed methods and headers include the request details.",
			"Avoid putting credentials on wildcard CORS responses."
		],
		confidence: .84
	});
	if (message.includes("failed to fetch") || message.includes("net::err") || entry.kind === "resource") suggestions.push({
		title: "Validate the resource URL and network state",
		explanation: "A script, image, stylesheet, or fetch request appears to be unavailable.",
		steps: [
			"Open the failing URL directly and confirm it returns the expected status.",
			"Check spelling, base paths, redirects, and local dev server ports.",
			"Inspect whether an ad blocker, CSP rule, or service worker is intercepting the request."
		],
		confidence: .78
	});
	if (message.includes("hydration")) suggestions.push({
		title: "Compare server and client rendered output",
		explanation: "Hydration warnings usually mean the initial HTML differs from the client render.",
		steps: [
			"Remove non-deterministic values from the first render.",
			"Move browser-only logic behind an effect or client-only boundary.",
			"Check time, random IDs, locale formatting, and environment-specific branches."
		],
		confidence: .82
	});
	if (entry.kind === "csp") suggestions.push({
		title: "Update the Content Security Policy intentionally",
		explanation: "A CSP rule blocked a script, style, connection, frame, or media resource.",
		steps: [
			"Identify the blocked directive and source.",
			"Prefer adding the exact trusted source over broad wildcards.",
			"Keep remote code out of extension pages and use packaged scripts only."
		],
		confidence: .8
	});
	if (suggestions.length === 0) suggestions.push({
		title: "Start from the first application stack frame",
		explanation: "The most actionable clue is usually the first stack frame that belongs to your app.",
		steps: [
			"Open the source file and line number shown with the issue.",
			"Reproduce once after clearing the console to isolate the first failure.",
			"Search the exact sanitized error message with framework or package context."
		],
		confidence: .62
	});
	return suggestions;
}
function buildSearchQueries(entry, settings = DEFAULT_SETTINGS) {
	const normalizedSettings = normalizeSettings(settings);
	const framework = entry.frameworkHints[0]?.name;
	const fileExt = entry.fileName?.split(".").pop();
	const baseQuery = [
		entry.cleanMessage || entry.message,
		framework,
		fileExt ? `${fileExt} browser console` : "browser console"
	].filter(Boolean).join(" ").slice(0, 240);
	return normalizedSettings.enabledSearchTargets.map((target) => ({
		target,
		query: baseQuery,
		url: buildSearchUrl(target, baseQuery)
	}));
}
function buildDebugReport(issue) {
	const topFix = issue.suggestedFixes[0];
	const firstEntry = issue.entries[0];
	const framework = issue.frameworkHints.map((hint) => hint.name).join(", ") || "Not detected";
	const stack = firstEntry?.stackTrace || "No stack trace captured.";
	const markdown = [
		`# ${issue.cleanMessage}`,
		"",
		`- Severity: ${issue.severity}`,
		`- Count: ${issue.count}`,
		`- Status: ${issue.status}`,
		`- Page: ${issue.pageUrl || "Unknown"}`,
		`- Source: ${issue.fileName || issue.sourceUrl || "Unknown"}${issue.line ? `:${issue.line}` : ""}`,
		`- Framework hints: ${framework}`,
		`- First seen: ${new Date(issue.firstSeen).toISOString()}`,
		`- Last seen: ${new Date(issue.lastSeen).toISOString()}`,
		"",
		"## Likely Cause",
		topFix?.explanation || "Review the first application stack frame and reproduce from a clean console.",
		"",
		"## Suggested Fixes",
		...topFix?.steps.map((step, index) => `${index + 1}. ${step}`) || ["1. Reproduce the issue after clearing previous logs.", "2. Open the source frame and verify the failing value or resource."],
		"",
		"## Sanitized Stack Trace",
		"```text",
		stack,
		"```",
		"",
		issue.notes ? `## Notes\n${issue.notes}` : ""
	].filter(Boolean).join("\n");
	return {
		title: issue.cleanMessage,
		markdown,
		generatedAt: Date.now(),
		sanitized: issue.sanitizationStatus.maskedCount > 0
	};
}
function formatTimestamp(timestamp) {
	return new Intl.DateTimeFormat(void 0, {
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit"
	}).format(timestamp);
}
//#endregion
//#region src/core/logStore.ts
function createConsoleEntry(payload, settings = DEFAULT_SETTINGS) {
	const normalizedSettings = normalizeSettings(settings);
	const message = payload.message || payload.args?.join(" ") || "Console event captured";
	const sanitizationStatus = sanitizeText(message, normalizedSettings);
	const stack = payload.stackTrace ? parseStack(payload.stackTrace) : [];
	const firstFrame = stack.find((frame) => !frame.fileName.includes("betterConsole")) || stack[0];
	const sourceUrl = payload.sourceUrl || firstFrame?.fileName;
	const fileName = payload.fileName || (sourceUrl ? sourceUrl.split("/").pop() : void 0);
	const frameworkHints = detectFrameworkHints(`${message}\n${payload.stackTrace || ""}`, payload.pageUrl || payload.frameUrl || "");
	const level = payload.level || "log";
	const kind = payload.kind || "console";
	const entry = {
		id: payload.id || crypto.randomUUID(),
		kind,
		level,
		message,
		cleanMessage: sanitizationStatus.cleanText,
		originalMessage: message,
		args: payload.args || [message],
		timestamp: payload.timestamp || Date.now(),
		sourceUrl,
		fileName,
		line: payload.line || firstFrame?.lineNumber,
		column: payload.column || firstFrame?.columnNumber,
		stack,
		stackTrace: payload.stackTrace ? sanitizeText(payload.stackTrace, normalizedSettings).cleanText : void 0,
		tabId: payload.tabId,
		tabTitle: payload.tabTitle,
		pageUrl: payload.pageUrl,
		frameUrl: payload.frameUrl,
		userAgent: payload.userAgent,
		severity: getSeverity(level, kind, message),
		status: "open",
		notes: "",
		tags: [],
		frameworkHints,
		suggestedFixes: [],
		searchQueries: [],
		sanitizationStatus
	};
	entry.suggestedFixes = buildFixSuggestions(entry);
	entry.searchQueries = buildSearchQueries(entry, normalizedSettings);
	return entry;
}
function getFingerprint(entry) {
	const source = entry.fileName || entry.sourceUrl || "unknown-source";
	const line = entry.line || 0;
	const normalizedMessage = entry.cleanMessage.toLowerCase().replace(/\d+/g, "#").replace(/\s+/g, " ").trim();
	return [
		entry.kind,
		entry.level,
		normalizedMessage,
		source,
		line
	].join("|");
}
function groupLogs(entries) {
	const map = /* @__PURE__ */ new Map();
	for (const e of entries) {
		if (e.status === "ignored") continue;
		const key = getFingerprint(e);
		const existing = map.get(key);
		if (existing) {
			existing.count += 1;
			existing.entries.push(e);
			existing.lastSeen = Math.max(existing.lastSeen, e.timestamp);
			existing.firstSeen = Math.min(existing.firstSeen, e.timestamp);
			if (severityScore(e.severity) > severityScore(existing.severity)) existing.severity = e.severity;
			if (e.status === "bookmarked") existing.status = "bookmarked";
		} else map.set(key, {
			id: key,
			fingerprint: key,
			level: e.level,
			kind: e.kind,
			severity: e.severity,
			message: e.message,
			cleanMessage: e.cleanMessage,
			count: 1,
			status: e.status,
			firstSeen: e.timestamp,
			lastSeen: e.timestamp,
			sourceUrl: e.sourceUrl,
			fileName: e.fileName,
			line: e.line,
			column: e.column,
			tabId: e.tabId,
			pageUrl: e.pageUrl,
			frameworkHints: e.frameworkHints,
			suggestedFixes: e.suggestedFixes,
			searchQueries: e.searchQueries,
			sanitizationStatus: e.sanitizationStatus,
			notes: e.notes,
			entries: [e]
		});
	}
	return Array.from(map.values()).sort((a, b) => {
		const severityDelta = severityScore(b.severity) - severityScore(a.severity);
		if (severityDelta !== 0) return severityDelta;
		return b.lastSeen - a.lastSeen;
	});
}
function filterGroups(groups, query, level) {
	const needle = query.trim().toLowerCase();
	return groups.filter((group) => {
		const matchesLevel = level === "all" || group.level === level;
		const matchesQuery = !needle || group.cleanMessage.toLowerCase().includes(needle) || group.fileName?.toLowerCase().includes(needle) || group.frameworkHints.some((hint) => hint.name.toLowerCase().includes(needle));
		return matchesLevel && matchesQuery;
	});
}
function applyEntryUpdate(entries, fingerprint, update) {
	return entries.map((entry) => getFingerprint(entry) === fingerprint ? {
		...entry,
		...update,
		status: update.status || entry.status
	} : entry);
}
function pruneLogs(entries, settings) {
	const cutoff = Date.now() - settings.retentionDays * 24 * 60 * 60 * 1e3;
	return entries.filter((entry) => entry.timestamp >= cutoff || entry.status === "bookmarked").slice(-settings.maxLogs);
}
function exportIssues(groups, format) {
	if (format === "json") return JSON.stringify(groups, null, 2);
	if (format === "text") return groups.map((group) => `[${group.severity}] ${group.cleanMessage} x${group.count} ${group.fileName || ""}`).join("\n");
	return groups.map((group) => [
		`## ${group.cleanMessage}`,
		"",
		`- Severity: ${group.severity}`,
		`- Count: ${group.count}`,
		`- Source: ${group.fileName || group.sourceUrl || "Unknown"}${group.line ? `:${group.line}` : ""}`,
		`- Status: ${group.status}`
	].join("\n")).join("\n\n");
}
function severityScore(severity) {
	return {
		low: 1,
		medium: 2,
		high: 3,
		critical: 4
	}[severity];
}
//#endregion
export { groupLogs as a, buildPreferredSolutionSearchUrl as c, getPreferredSearchTarget as d, DEFAULT_SETTINGS as f, filterGroups as i, buildSearchUrl as l, normalizeSettings as m, createConsoleEntry as n, pruneLogs as o, STORAGE_KEYS as p, exportIssues as r, buildDebugReport as s, applyEntryUpdate as t, formatTimestamp as u };
