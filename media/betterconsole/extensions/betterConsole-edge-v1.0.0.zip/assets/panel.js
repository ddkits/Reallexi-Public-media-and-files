import { g as require_client, h as require_jsx_runtime, v as __toESM } from "./styles.js";
import "./modulepreload-polyfill.js";
import { t as ConsoleDashboard } from "./ConsoleDashboard.js";
//#region src/devtools/panel.tsx
var import_client = /* @__PURE__ */ __toESM(require_client());
var import_jsx_runtime = require_jsx_runtime();
import_client.createRoot(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsoleDashboard, { variant: "panel" }));
//#endregion
