const WINDOW_FLAG = '__betterConsoleBridgeInstalled__';
const PAGE_BRIDGE_EVENT = 'betterConsole:capture';
const CONSOLE_LEVELS = ['log', 'info', 'warn', 'error', 'debug'];

function safeStringify(value) {
  if (typeof value === 'string') return value;
  if (value instanceof Error) return `${value.name}: ${value.message}`;

  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

function uuid() {
  return crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function emit(payload) {
  window.postMessage(
    {
      source: PAGE_BRIDGE_EVENT,
      payload: {
        id: uuid(),
        timestamp: Date.now(),
        pageUrl: location.href,
        frameUrl: window.frameElement ? document.referrer || location.href : location.href,
        userAgent: navigator.userAgent,
        ...payload,
      },
    },
    '*',
  );
}

function parseErrorSource(error) {
  const stackTrace = error.stack || '';
  const firstFrame = stackTrace.split('\n').find((line) => /:\d+:\d+/.test(line));
  const match = firstFrame?.match(
    /(https?:\/\/[^)\s]+|webpack-internal:\/\/\/[^)\s]+|file:\/\/\/[^)\s]+):(\d+):(\d+)/,
  );

  return {
    stackTrace,
    sourceUrl: match?.[1],
    line: match ? Number(match[2]) : undefined,
    column: match ? Number(match[3]) : undefined,
  };
}

function installConsoleCapture() {
  const originalConsoleMethods = {};

  CONSOLE_LEVELS.forEach((level) => {
    originalConsoleMethods[level] = console[level].bind(console);
    console[level] = (...args) => {
      const callSite = new Error();
      emit({
        kind: 'console',
        level,
        message: args.map(safeStringify).join(' '),
        args: args.map(safeStringify),
        ...parseErrorSource(callSite),
      });
      originalConsoleMethods[level]?.(...args);
    };
  });
}

function installErrorCapture() {
  window.addEventListener(
    'error',
    (event) => {
      const target = event.target;
      const resourceUrl =
        target instanceof HTMLElement ? target.getAttribute('src') || target.getAttribute('href') || undefined : undefined;

      if (resourceUrl) {
        emit({
          kind: 'resource',
          level: 'warn',
          message: `Failed resource load: ${resourceUrl}`,
          args: [resourceUrl],
          sourceUrl: resourceUrl,
        });
        return;
      }

      const error = event.error instanceof Error ? event.error : new Error(event.message);
      emit({
        kind: 'runtime',
        level: 'error',
        message: event.message || error.message,
        args: [event.message || error.message],
        sourceUrl: event.filename,
        line: event.lineno,
        column: event.colno,
        ...parseErrorSource(error),
      });
    },
    true,
  );

  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason instanceof Error ? event.reason : new Error(safeStringify(event.reason));
    emit({
      kind: 'promise',
      level: 'error',
      message: reason.message,
      args: [safeStringify(event.reason)],
      ...parseErrorSource(reason),
    });
  });

  document.addEventListener('securitypolicyviolation', (event) => {
    emit({
      kind: 'csp',
      level: 'error',
      message: `CSP blocked ${event.violatedDirective}: ${event.blockedURI}`,
      args: [event.violatedDirective, event.blockedURI],
      sourceUrl: event.sourceFile,
      line: event.lineNumber,
      column: event.columnNumber,
    });
  });
}

if (!window[WINDOW_FLAG]) {
  window[WINDOW_FLAG] = true;
  installConsoleCapture();
  installErrorCapture();
}
