import { _ as require_react, a as CopyIcon, c as PanelIcon, d as RefreshIcon, f as SearchIcon, h as require_jsx_runtime, i as ChevronDownIcon, l as PauseIcon, m as TrashIcon, n as SponsorButton, o as DownloadIcon, p as SettingsIcon, r as SupportLinks, s as ExternalLinkIcon, t as useExtensionState, u as PlayIcon } from "./styles.js";
import { d as getPreferredSearchTarget, l as buildSearchUrl, r as exportIssues, s as buildDebugReport, u as formatTimestamp } from "./logStore.js";
//#region src/ui/ConsoleDashboard.tsx
var import_react = require_react();
var import_jsx_runtime = require_jsx_runtime();
var LEVELS = [
	"all",
	"error",
	"warn",
	"info",
	"log",
	"debug"
];
function ConsoleDashboard({ variant }) {
	const { state, query, setQuery, levelFilter, setLevelFilter, tabScope, setTabScope, scopedGroups, filteredGroups, selectedIssue, selectedFingerprint, setSelectedFingerprint, notice, setNotice, currentTabTitle, currentTabUrl, actions } = useExtensionState();
	const stats = (0, import_react.useMemo)(() => getStats(scopedGroups), [scopedGroups]);
	(0, import_react.useEffect)(() => {
		if (!notice) return void 0;
		const timer = window.setTimeout(() => setNotice(""), 2500);
		return () => window.clearTimeout(timer);
	}, [notice, setNotice]);
	if (variant === "popup") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bc-app bc-popup",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, { compact: true }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabContext, {
				title: currentTabTitle,
				url: currentTabUrl
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "bc-popup-summary",
				"aria-label": "Current tab console health",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Errors",
						value: stats.errors,
						tone: "critical"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Warnings",
						value: stats.warnings,
						tone: "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Repeated",
						value: stats.repeated,
						tone: "info"
					})
				]
			}),
			selectedIssue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IssueSummary, { issue: selectedIssue }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bc-toolbar bc-popup-actions",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => actions.openSidePanel(),
						title: "Open side panel",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Side panel" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => actions.refreshCapture(),
						title: "Refresh capture on this tab",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Refresh tab" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => actions.saveSettings({ captureEnabled: !state.settings.captureEnabled }),
						title: state.settings.captureEnabled ? "Pause capture" : "Resume capture",
						children: [state.settings.captureEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PauseIcon, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: state.settings.captureEnabled ? "Pause" : "Resume" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => actions.openOptions(),
						title: "Open settings",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Settings" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => actions.clearLogs("tab"),
						title: "Clear current tab logs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrashIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Clear tab" })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SupportLinks, {}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toast, { message: notice })
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `bc-app bc-${variant}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "bc-topbar",
				"aria-label": "Search and filters",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "bc-search",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							"aria-label": "Search captured issues",
							onChange: (event) => setQuery(event.target.value),
							placeholder: "Search message, source, or framework",
							value: query
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bc-segmented bc-scope-toggle",
						"aria-label": "Tab scope",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: tabScope === "current" ? "active" : "",
							onClick: () => setTabScope("current"),
							type: "button",
							children: "Current tab"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: tabScope === "all" ? "active" : "",
							onClick: () => setTabScope("all"),
							type: "button",
							children: "All tabs"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bc-segmented",
						"aria-label": "Level filter",
						children: LEVELS.map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: levelFilter === level ? "active" : "",
							onClick: () => setLevelFilter(level),
							type: "button",
							children: level
						}, level))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bc-toolbar",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => actions.refreshCapture(),
								title: "Refresh capture on this tab",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Refresh tab" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => actions.saveSettings({ captureEnabled: !state.settings.captureEnabled }),
								title: state.settings.captureEnabled ? "Pause capture" : "Resume capture",
								children: [state.settings.captureEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PauseIcon, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: state.settings.captureEnabled ? "Pause" : "Resume" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => actions.clearLogs(tabScope === "current" ? "tab" : "all"),
								title: tabScope === "current" ? "Clear current tab logs" : "Clear all captured logs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrashIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tabScope === "current" ? "Clear tab" : "Clear all" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => actions.downloadText(`betterconsole-issues-${Date.now()}.json`, "application/json", exportIssues(filteredGroups, "json")),
								title: "Export filtered issues as JSON",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Export" })]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "bc-workspace",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "bc-vision",
					"aria-label": "Vision Mode",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Vision Mode" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabContext, {
							compact: true,
							scope: tabScope,
							title: currentTabTitle,
							url: currentTabUrl
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bc-metrics",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
									label: "Errors",
									value: stats.errors,
									tone: "critical"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
									label: "Warnings",
									value: stats.warnings,
									tone: "warning"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
									label: "New",
									value: stats.newIssues,
									tone: "info"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
									label: "Most repeated",
									value: stats.mostRepeated,
									tone: "neutral"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "bc-health",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Top source" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: stats.topSource || "No source yet" })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Framework" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: stats.framework || "Not detected" })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Priority" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: stats.priority })] })
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bc-issue-list",
					"aria-label": "Grouped issues",
					children: filteredGroups.length ? filteredGroups.map((issue) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IssueAccordion, {
						expanded: selectedIssue?.fingerprint === issue.fingerprint,
						issue,
						onCopy: actions.copyText,
						onDownload: actions.downloadText,
						onFindSolution: actions.openSolutionSearch,
						onToggle: () => setSelectedFingerprint(issue.fingerprint),
						onUpdate: actions.updateIssue,
						selected: selectedFingerprint === issue.fingerprint
					}, issue.fingerprint)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {})
				})]
			}),
			variant !== "panel" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SupportLinks, {}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toast, { message: notice })
		]
	});
}
function Header({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "bc-header",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bc-brand",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				alt: "",
				height: "32",
				src: "/assets/icons/icon-32.png",
				width: "32"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "betterConsole" }), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Console cleanup, search, fixes, and reports" })] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SponsorButton, {})]
	});
}
function Metric({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `bc-metric ${tone}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: value })]
	});
}
function IssueAccordion({ issue, expanded, selected, onToggle, onUpdate, onCopy, onDownload, onFindSolution }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: `bc-issue-card ${expanded ? "expanded" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			"aria-expanded": expanded,
			className: `bc-issue-row ${selected ? "selected" : ""}`,
			onClick: onToggle,
			type: "button",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `bc-severity ${issue.severity}`,
					children: issue.severity
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: issue.cleanMessage }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					issue.fileName || "Unknown source",
					issue.line ? `:${issue.line}` : "",
					" - last seen ",
					formatTimestamp(issue.lastSeen)
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("em", { children: ["x", issue.count] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDownIcon, { className: "bc-accordion-icon" })
			]
		}), expanded && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IssueAccordionBody, {
			issue,
			onCopy,
			onDownload,
			onFindSolution,
			onUpdate
		})]
	});
}
function IssueSummary({ issue }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "bc-issue-summary",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `bc-severity ${issue.severity}`,
				children: issue.severity
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: issue.cleanMessage }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				issue.fileName || "Unknown source",
				issue.line ? `:${issue.line}` : "",
				" - repeated ",
				issue.count
			] })
		]
	});
}
function TabContext({ compact = false, scope = "current", title, url }) {
	const label = scope === "all" ? "All tabs" : "Current tab";
	const detail = scope === "all" ? "Every captured tab" : title || formatHost(url) || "Active tab";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `bc-tab-context ${compact ? "compact" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: detail })]
	});
}
function IssueAccordionBody({ issue, onUpdate, onCopy, onDownload, onFindSolution }) {
	const [notes, setNotes] = (0, import_react.useState)("");
	const [searchDraft, setSearchDraft] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setNotes(issue?.notes || "");
		setSearchDraft(issue?.searchQueries[0]?.query || issue?.cleanMessage || "");
	}, [issue]);
	const report = buildDebugReport(issue);
	const rootSuggestion = issue.suggestedFixes[0];
	const solutionSteps = issue.suggestedFixes.flatMap((suggestion) => suggestion.steps).slice(0, 6);
	const preferredTarget = getPreferredSearchTarget(typeof navigator === "undefined" ? "" : navigator.userAgent);
	const preferredUrl = buildSearchUrl(preferredTarget, searchDraft);
	const searchLinks = issue.searchQueries.map((searchQuery) => {
		const url = buildSearchUrl(searchQuery.target, searchDraft);
		return {
			target: searchQuery.target,
			url,
			visibleUrl: formatVisibleUrl(url)
		};
	});
	const firstEntry = issue.entries[0];
	const firstFrame = firstEntry?.stack?.[0];
	const source = issue.fileName || issue.sourceUrl || firstFrame?.fileName || "Unknown source";
	const sourceLine = issue.line || firstFrame?.lineNumber;
	const page = issue.pageUrl || firstEntry?.pageUrl || firstEntry?.frameUrl || "Unknown page";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bc-issue-accordion-body",
		"aria-label": "Issue details",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "bc-root-cause",
				"aria-label": "Root cause",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: rootSuggestion?.title || "Start from the first application stack frame" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: rootSuggestion?.explanation || "The source and first stack frame usually point to the failing code path." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onFindSolution(searchDraft),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchIcon, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Find solution" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLinkIcon, {})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "bc-meta",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Coming from" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [source, sourceLine ? `:${sourceLine}` : ""] })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Page" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: page })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Framework" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: issue.frameworkHints.map((hint) => hint.name).join(", ") || "Not detected" })] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bc-actions",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onUpdate(issue.fingerprint, { status: "fixed" }),
						children: "Mark fixed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onUpdate(issue.fingerprint, { status: "bookmarked" }),
						children: "Bookmark"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onUpdate(issue.fingerprint, { status: "ignored" }),
						children: "Ignore"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "bc-how-to-solve",
				"aria-label": "How to solve this issue",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "How To Solve" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", { children: solutionSteps.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: step }, step)) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "bc-search-online",
				"aria-label": "Online fix search",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Research" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Filtered sanitized query" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: searchDraft,
						onChange: (event) => setSearchDraft(event.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "bc-preferred-search",
						href: preferredUrl,
						rel: "noreferrer",
						target: "_blank",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchIcon, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [preferredTarget, " solution search"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: formatVisibleUrl(preferredUrl) })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLinkIcon, {})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bc-search-links",
						children: searchLinks.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: link.url,
							rel: "noreferrer",
							target: "_blank",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchIcon, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: link.target }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: link.visibleUrl })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLinkIcon, {})
							]
						}, link.target))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "bc-notes",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Notes" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					onChange: (event) => setNotes(event.target.value),
					value: notes
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bc-actions",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onUpdate(issue.fingerprint, { notes }),
					children: "Save notes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onCopy(issue.cleanMessage, "Issue copied"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Copy issue" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "bc-report",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", { children: "Report and stack" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bc-actions",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onCopy(report.markdown, "Debug report copied"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Copy report" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onDownload(`betterconsole-report-${Date.now()}.md`, "text/markdown", report.markdown),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Download report" })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", { children: issue.entries[0]?.stackTrace || "No stack trace captured." })
				]
			})
		]
	});
}
function EmptyState() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bc-empty",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "No captured issues yet" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Open a page, reproduce a console message, and betterConsole will organize it here." })]
	});
}
function Toast({ message }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "bc-toast",
		children: message
	});
}
function formatVisibleUrl(url) {
	try {
		const parsed = new URL(url);
		return `${parsed.hostname}${parsed.pathname}${parsed.search}`;
	} catch {
		return url;
	}
}
function formatHost(url) {
	if (!url) return "";
	try {
		return new URL(url).hostname;
	} catch {
		return url;
	}
}
function getStats(groups) {
	return {
		errors: groups.filter((group) => group.level === "error").reduce((sum, group) => sum + group.count, 0),
		warnings: groups.filter((group) => group.level === "warn").reduce((sum, group) => sum + group.count, 0),
		repeated: groups.filter((group) => group.count > 1).length,
		mostRepeated: groups.reduce((max, group) => Math.max(max, group.count), 0),
		topSource: groups[0]?.fileName || groups[0]?.sourceUrl || "",
		framework: groups.flatMap((group) => group.frameworkHints)[0]?.name || "",
		priority: groups.find((group) => group.severity === "critical")?.cleanMessage || groups.find((group) => group.severity === "high")?.cleanMessage || "Keep watching the current page",
		newIssues: groups.filter((group) => Date.now() - group.lastSeen < 600 * 1e3).length
	};
}
//#endregion
export { ConsoleDashboard as t };
