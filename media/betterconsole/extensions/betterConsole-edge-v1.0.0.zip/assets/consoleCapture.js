const CONTENT_BRIDGE_EVENT = 'betterConsole:capture';
const BRIDGE_SCRIPT_ID = 'betterconsole-page-bridge';
const CONTENT_CAPTURE_FLAG = '__betterConsoleContentCaptureInstalled__';

function injectBridge() {
  if (document.getElementById(BRIDGE_SCRIPT_ID)) return;

  const parent = document.documentElement || document.head || document.body;
  if (!parent) {
    document.addEventListener('DOMContentLoaded', injectBridge, { once: true });
    return;
  }

  const bridgeScript = document.createElement('script');
  bridgeScript.id = BRIDGE_SCRIPT_ID;
  bridgeScript.src = chrome.runtime.getURL('assets/pageConsoleBridge.js');
  bridgeScript.async = false;
  bridgeScript.onload = () => bridgeScript.remove();
  parent.appendChild(bridgeScript);
}

function isCapturePayload(value) {
  if (!value || typeof value !== 'object') return false;

  return value.id !== undefined && value.message !== undefined && value.kind !== undefined;
}

if (!window[CONTENT_CAPTURE_FLAG]) {
  window[CONTENT_CAPTURE_FLAG] = true;

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;

    const data = event.data;
    if (data?.source !== CONTENT_BRIDGE_EVENT || !isCapturePayload(data.payload)) return;

    chrome.runtime.sendMessage({ type: 'logEntry', payload: data.payload }).catch(() => {
      // The extension context can be invalidated during reloads or updates.
    });
  });

  injectBridge();
}
