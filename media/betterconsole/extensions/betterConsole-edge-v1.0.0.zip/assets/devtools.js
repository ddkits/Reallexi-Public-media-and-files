import "./modulepreload-polyfill.js";
//#region src/devtools/devtools.ts
chrome.devtools.panels.create("betterConsole", "", "src/devtools/panel.html");
//#endregion
