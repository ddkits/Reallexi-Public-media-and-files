import { _ as require_react, g as require_client, h as require_jsx_runtime, n as SponsorButton, r as SupportLinks, t as useExtensionState, v as __toESM } from "./styles.js";
import "./modulepreload-polyfill.js";
import { f as DEFAULT_SETTINGS } from "./logStore.js";
//#region src/options/options.tsx
var import_client = /* @__PURE__ */ __toESM(require_client());
var import_react = require_react();
var import_jsx_runtime = require_jsx_runtime();
function OptionsPage() {
	const { state, actions, notice } = useExtensionState();
	const [draft, setDraft] = (0, import_react.useState)(state.settings || DEFAULT_SETTINGS);
	(0, import_react.useEffect)(() => {
		setDraft(state.settings || DEFAULT_SETTINGS);
	}, [state.settings]);
	const update = (key, value) => {
		setDraft((current) => ({
			...current,
			[key]: value
		}));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bc-app bc-options",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "bc-header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bc-brand",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						alt: "",
						height: "32",
						src: "/assets/icons/icon-32.png",
						width: "32"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "betterConsole Settings" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Privacy, retention, cleanup, and search preferences" })] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SponsorButton, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "bc-options-main",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "bc-suggestions",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "General" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Capture console activity",
								value: draft.captureEnabled,
								onChange: (value) => update("captureEnabled", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "bc-option-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Theme" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: draft.theme,
									onChange: (event) => update("theme", event.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "system",
											children: "System"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "dark",
											children: "Dark"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "light",
											children: "Light"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "bc-option-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Retention days" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									min: "1",
									type: "number",
									value: draft.retentionDays,
									onChange: (event) => update("retentionDays", Number(event.target.value))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "bc-option-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Max logs stored locally" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									min: "100",
									step: "100",
									type: "number",
									value: draft.maxLogs,
									onChange: (event) => update("maxLogs", Number(event.target.value))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "bc-option-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "On browser startup" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: draft.startupLogMode,
									onChange: (event) => update("startupLogMode", event.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "keep",
										children: "Keep old logs"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "reset",
										children: "Reset logs"
									})]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "bc-suggestions",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Privacy Sanitization" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Mask secrets and tokens",
								value: draft.maskSecrets,
								onChange: (value) => update("maskSecrets", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Mask email addresses",
								value: draft.maskEmails,
								onChange: (value) => update("maskEmails", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Remove URL query parameters",
								value: draft.maskQueryParams,
								onChange: (value) => update("maskQueryParams", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Mask private URLs",
								value: draft.maskPrivateUrls,
								onChange: (value) => update("maskPrivateUrls", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Mask IP addresses",
								value: draft.maskIpAddresses,
								onChange: (value) => update("maskIpAddresses", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Mask localhost ports",
								value: draft.maskLocalhostPorts,
								onChange: (value) => update("maskLocalhostPorts", value)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "bc-suggestions",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Console Cleanup" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Collapse duplicate messages",
								value: draft.cleanupDuplicates,
								onChange: (value) => update("cleanupDuplicates", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Hide known extension noise",
								value: draft.hideExtensionNoise,
								onChange: (value) => update("hideExtensionNoise", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Developer mode",
								value: draft.developerMode,
								onChange: (value) => update("developerMode", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "bc-option-row stacked",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Ignored patterns" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									value: draft.ignoredPatterns.join("\n"),
									onChange: (event) => update("ignoredPatterns", event.target.value.split("\n").filter(Boolean))
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bc-actions",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => actions.saveSettings(draft),
								children: "Save settings"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setDraft(DEFAULT_SETTINGS),
								children: "Reset defaults"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => actions.clearLogs("all"),
								children: "Reset all logs now"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SupportLinks, {}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bc-toast",
				children: notice
			})
		]
	});
}
function Toggle({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "bc-toggle",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			checked: value,
			onChange: (event) => onChange(event.target.checked),
			type: "checkbox"
		})]
	});
}
import_client.createRoot(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OptionsPage, {}));
//#endregion
